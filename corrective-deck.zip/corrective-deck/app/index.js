// app/index.js
import App from '../App';

// Expo Router expects a default export from each route file.
// We just reuse the existing App component (stack navigator + screens).
export default App;
